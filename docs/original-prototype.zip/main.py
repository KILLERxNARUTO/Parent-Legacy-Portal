"""
Edutainal Ventures — Smart Parent Legacy Dashboard & Portfolio Portal
FastAPI Backend + 8-Pillar STEAMRE Cosine-Similarity Career Revelation Engine
"""
from datetime import date
from typing import List, Optional
import math
import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

app = FastAPI(
    title="Edutainal Ventures — Smart Parent Legacy & Portfolio API",
    description="Backend API for Edutainal Maverick World (Crescent University Incubation Hub) tracking 50-210 curated 3-hour sessions, 8-pillar STEAMRE vectors, UN SDGs, and AI Career Revelation.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

STEAMRE_PILLARS = [
    "Science", "Technology", "Research", "Engineering",
    "Arts", "Mathematics", "Energy", "Resilience"
]

CAREER_ARCHETYPES = [
    {
        "title": "Autonomous Mobility & ADAS Systems Architect",
        "zones": "Moto Morphosis + Robotics + Code Craft",
        "weights": [82, 96, 85, 95, 70, 92, 88, 84],
        "next_zone": "Moto Morphosis Zone — Driverless Demo (Scaled City ADAS)",
    },
    {
        "title": "Aerospace & Orbital Habitation Systems Engineer",
        "zones": "Space Science + Rocketry + Cosmic Living",
        "weights": [94, 90, 92, 93, 76, 94, 91, 85],
        "next_zone": "Space Science & Astronomy Zone — Moon Base Alpha",
    },
    {
        "title": "Spatial Computing, AI & Full-Stack Product Creator",
        "zones": "Code Craft + Cinematic Studio + Robotics",
        "weights": [80, 98, 86, 90, 92, 90, 75, 84],
        "next_zone": "Code Craft & Immersive Tech Zone — AI Agent & Holographic Lab",
    },
    {
        "title": "Biomedical Robotics & Neuro-Health Innovator",
        "zones": "BioTech & Healthcare + Mind-Body Mastery + Robotics",
        "weights": [96, 88, 95, 89, 78, 85, 84, 92],
        "next_zone": "BioTech & Healthcare Zone — Build a Bionic Limb",
    },
    {
        "title": "Climate-Tech & Sustainable Smart-City Architect",
        "zones": "Cosmic Living + BioTech + Moto Morphosis",
        "weights": [89, 85, 88, 91, 90, 84, 97, 88],
        "next_zone": "Cosmic Living Zone — Green Architect Renewable Microgrid",
    },
    {
        "title": "Deep-Tech Venture Founder & Global Policy Strategist",
        "zones": "Leadership Powerhouse + Cinematic Studio + Code Craft",
        "weights": [76, 86, 84, 80, 94, 82, 80, 98],
        "next_zone": "Leadership Powerhouse Zone — Startup Garage & Global CEO Boardroom",
    },
]


class SessionLogCreate(BaseModel):
    student_id: str
    zone_id: str
    zone_name: str
    signature_experience: str
    project_title: str
    category: str
    steamre_rubric: List[float] = Field(..., min_length=8, max_length=8)
    mentor_notes: str
    sdgs: List[str] = []
    observer_name: Optional[str] = "Edutainal Ventures Lead Evaluator"
    breakthrough_note: Optional[str] = ""
    friction_note: Optional[str] = ""
    action_plan: Optional[str] = ""
    behavioral_scores: Optional[dict] = None
    ip_status: Optional[str] = "Verified Class Certificate"
    session_hours: Optional[float] = 3.0


class StudentCreate(BaseModel):
    id: str
    name: str
    age: int
    world_tier: str = "meta"
    total_sessions: int = 0
    target_sessions: int = 210
    steamre: Optional[List[float]] = [90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0]


class StudentRecord(BaseModel):
    id: str
    name: str
    age: int
    world_tier: str
    total_sessions: int
    target_sessions: int
    steamre: List[float]


STUDENTS_DB = {
    "aarav": {
        "id": "aarav",
        "name": "Aarav Krishnan",
        "age": 14,
        "world_tier": "meta",
        "total_sessions": 142,
        "target_sessions": 210,
        "steamre": [96.0, 99.0, 96.0, 98.0, 95.0, 98.0, 96.0, 97.0],
        "logs": [],
    },
    "zoya": {
        "id": "zoya",
        "name": "Zoya Al-Mansoor",
        "age": 17,
        "world_tier": "meta",
        "total_sessions": 186,
        "target_sessions": 210,
        "steamre": [98.0, 96.0, 99.0, 96.0, 97.0, 96.0, 98.0, 99.0],
        "logs": [],
    },
    "rohan": {
        "id": "rohan",
        "name": "Rohan Verma",
        "age": 9,
        "world_tier": "genesis",
        "total_sessions": 96,
        "target_sessions": 150,
        "steamre": [96.0, 97.0, 95.0, 97.0, 98.0, 96.0, 95.0, 96.0],
        "logs": [],
    },
}


def compute_cosine_affinity(vec_a: List[float], vec_b: List[float]) -> float:
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    norm_a = math.sqrt(sum(a * a for a in vec_a))
    norm_b = math.sqrt(sum(b * b for b in vec_b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    raw = dot / (norm_a * norm_b)
    avg_mag = sum(vec_a) / (len(vec_a) * 100.0)
    blended = (raw * 0.78 + avg_mag * 0.22) * 100.0
    return round(min(99.4, max(60.0, blended)), 1)


FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")
FRONTEND_INDEX = os.path.join(FRONTEND_DIR, "index.html")
FRONTEND_OBSERVER = os.path.join(FRONTEND_DIR, "observer.html")
ASSETS_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
if os.path.exists(ASSETS_DIR):
    app.mount("/assets", StaticFiles(directory=ASSETS_DIR), name="assets")


@app.get("/", include_in_schema=False)
def serve_index():
    if os.path.exists(FRONTEND_INDEX):
        return FileResponse(FRONTEND_INDEX)
    return {"message": "Edutainal Ventures Backend API running. Interactive docs at /docs"}


@app.get("/observer", include_in_schema=False)
@app.get("/company", include_in_schema=False)
def serve_observer():
    if os.path.exists(FRONTEND_OBSERVER):
        return FileResponse(FRONTEND_OBSERVER)
    return {"message": "Observer dashboard template not found. Ensure frontend/observer.html exists."}


@app.get("/api/v1/health")
def health_check():
    return {
        "status": "healthy",
        "service": "Edutainal Ventures — Smart Parent Legacy & Company Observer API",
        "students_count": len(STUDENTS_DB),
        "pillars": STEAMRE_PILLARS,
    }


@app.get("/api/v1/students", response_model=List[StudentRecord])
def list_students():
    return list(STUDENTS_DB.values())


@app.post("/api/v1/students", response_model=StudentRecord)
def create_student(payload: StudentCreate):
    sid = payload.id.lower().strip()
    if sid in STUDENTS_DB:
        raise HTTPException(status_code=400, detail="Student already exists")
    new_student = {
        "id": sid,
        "name": payload.name,
        "age": payload.age,
        "world_tier": payload.world_tier,
        "total_sessions": payload.total_sessions,
        "target_sessions": payload.target_sessions,
        "steamre": payload.steamre or [90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0, 90.0],
        "logs": [],
    }
    STUDENTS_DB[sid] = new_student
    return new_student


@app.get("/api/v1/students/{student_id}", response_model=StudentRecord)
def get_student(student_id: str):
    if student_id not in STUDENTS_DB:
        raise HTTPException(status_code=404, detail="Student not found")
    return STUDENTS_DB[student_id]


@app.get("/api/v1/students/{student_id}/logs")
def get_student_logs(student_id: str):
    if student_id not in STUDENTS_DB:
        raise HTTPException(status_code=404, detail="Student not found")
    return {"student_id": student_id, "logs": STUDENTS_DB[student_id].get("logs", [])}


@app.get("/api/v1/career-revelation/{student_id}")
def get_career_revelation(student_id: str):
    if student_id not in STUDENTS_DB:
        raise HTTPException(status_code=404, detail="Student not found")
    student = STUDENTS_DB[student_id]
    vec = student["steamre"]
    matches = []
    for arch in CAREER_ARCHETYPES:
        score = compute_cosine_affinity(vec, arch["weights"])
        matches.append({**arch, "affinity_score": score})
    matches.sort(key=lambda x: x["affinity_score"], reverse=True)
    return {
        "student_id": student_id,
        "steamre_vector": dict(zip(STEAMRE_PILLARS, vec)),
        "revealed_careers": matches,
    }


@app.post("/api/v1/sessions")
def log_curated_session(payload: SessionLogCreate):
    if payload.student_id not in STUDENTS_DB:
        raise HTTPException(status_code=404, detail="Student not found")
    st = STUDENTS_DB[payload.student_id]
    # Exponentially Weighted Moving Average (EWMA) update of 8-pillar STEAMRE vector
    st["steamre"] = [
        round(min(100.0, old * 0.8 + new * 0.2), 1)
        for old, new in zip(st["steamre"], payload.steamre_rubric)
    ]
    st["total_sessions"] += 1
    record = {
        "date": str(date.today()),
        "zone_id": payload.zone_id,
        "zone_name": payload.zone_name,
        "signature_experience": payload.signature_experience,
        "project_title": payload.project_title,
        "category": payload.category,
        "mentor_notes": payload.mentor_notes,
        "observer_name": payload.observer_name,
        "breakthrough_note": payload.breakthrough_note,
        "friction_note": payload.friction_note,
        "action_plan": payload.action_plan,
        "behavioral_scores": payload.behavioral_scores or {},
        "ip_status": payload.ip_status,
        "sdgs": payload.sdgs,
        "session_hours": payload.session_hours,
        "updated_steamre": st["steamre"],
    }
    st["logs"].insert(0, record)
    return {
        "status": "logged",
        "total_sessions": st["total_sessions"],
        "total_hours": st["total_sessions"] * 3,
        "session": record,
        "student": st,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
